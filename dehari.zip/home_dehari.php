<?php
    session_start();
    if (!isset($_SESSION['user_id'])) {
       // header("Location: index.html");
       // exit();
    }
    $user_id = $_SESSION['user_id'];
    $user_name = $_SESSION['user_name'];



?>

<!DOCTYPE html>
<html lang="en">



<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dehari - Home</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/logo-nav.css" rel="stylesheet">
    <link href="css/home_dehari.css" rel="stylesheet">
    <link href="css/jquery.dataTables.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>



    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="images/logo_white.png" alt="" height="90">
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <!-- <li>
                        <a>hello, <?=$user_name?></a>
                    </li> -->
                    <li>
                        <a href="home_dehari.php">home</a>
                    </li>
                    <li>
                        <a href="find_dehari.php">find dehari</a>
                    </li>
                    <li>
                        <a href="post_dehari.php">post dehari</a>
                    </li>
                    <li>
                        <a href="#">messages</a>
                    </li>
                    <li>
                        <a href="#">notifications</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

<?
    //$db_dehari = mysql_connect('localhost','bluecu6_rehan','.dehari.');
        //mysql_select_db('bluecu6_dehari', $db_dehari);

        $db_dehari = mysqli_connect("localhost", "bluecu6_rehan", ".dehari.", "bluecu6_dehari");

        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }

        $query_user = 'SELECT * FROM dehari_user WHERE user_id = ' . $user_id ;

        // Perform Query
        $result_user = mysqli_query($db_dehari, $query_user);
        $result_user_array = mysqli_fetch_assoc($result_user);


        // INCOMING
        $user_incoming = $result_user_array['user_incoming'];
        $user_incoming_rating = $result_user_array['user_incoming_rating'];

        $incoming_bids = trim($result_user_array['user_incoming_bids'], ",");
        $incoming_in_progress = trim($result_user_array['user_incoming_in_progress'], ",");
        $incoming_completed = trim($result_user_array['user_incoming_completed'], ",");

        $query_incoming_bids = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $incoming_bids . ');';
        $query_incoming_in_progress = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $incoming_in_progress . ');';
        $query_incoming_completed = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $incoming_completed . ');';

        $result_incoming_bids = mysqli_query($db_dehari, $query_incoming_bids);
        $result_incoming_bids_array = array();
        if ($result_incoming_bids) {
            while ($result_incoming_bids_row = mysqli_fetch_assoc($result_incoming_bids))
                $result_incoming_bids_array[] = $result_incoming_bids_row;
        }
        

        $result_incoming_in_progress = mysqli_query($db_dehari, $query_incoming_in_progress);
        $result_incoming_in_progress_array = array();
        if ($result_incoming_in_progress) {
            while ($result_incoming_in_progress_row = mysqli_fetch_assoc($result_incoming_in_progress))
                    $result_incoming_in_progress_array[] = $result_incoming_in_progress_row;
        }

        $result_incoming_completed = mysqli_query($db_dehari, $query_incoming_completed);
        $result_incoming_completed_array = array();
        if ($result_incoming_completed) {
            while ($result_incoming_completed_row = mysqli_fetch_assoc($result_incoming_completed))
                    $result_incoming_completed_array[] = $result_incoming_completed_row;
        }


        //echo 'REHAN';
        //print_r( $result_incoming_bids_array );
        //echo 'REHAN';
        //print_r( $result_incoming_in_progress_array );
        //echo 'REHAN';
        //print_r( $result_incoming_completed_array );


        // OUTGOING
        $user_outgoing = $result_user_array['user_outgoing'];
        $user_outgoing_rating = $result_user_array['user_outgoing_rating'];

        $outgoing_posted = trim($result_user_array['user_outgoing_posted'], ",");
        $outgoing_bids_received = trim($result_user_array['user_outgoing_bids_received'], ",");
        $outgoing_in_progress = trim($result_user_array['user_outgoing_in_progress'], ",");
        $outgoing_completed = trim($result_user_array['user_outgoing_completed'], ",");

        $query_outgoing_posted = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $outgoing_posted . ');';
        $query_outgoing_bids_received = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $outgoing_bids_received . ');';
        $query_outgoing_in_progress = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $outgoing_in_progress . ');';
        $query_outgoing_completed = 'SELECT * FROM dehari_list WHERE dehari_id IN (' . $outgoing_completed . ');';

        $result_outgoing_posted = mysqli_query($db_dehari, $query_outgoing_posted);
        $result_outgoing_posted_array = array();
        if ($result_outgoing_posted) {
            while ($result_outgoing_posted_row = mysqli_fetch_assoc($result_outgoing_posted))
                    $result_outgoing_posted_array[] = $result_outgoing_posted_row;
        }

        $result_outgoing_bids_received = mysqli_query($db_dehari, $query_outgoing_bids_received);
        $result_outgoing_bids_received_array = array();
        if ($result_outgoing_bids_received) {
            while ($result_outgoing_bids_received_row = mysqli_fetch_assoc($result_outgoing_bids_received))
                    $result_outgoing_bids_received_array[] = $result_outgoing_bids_received_row;
        }

        $result_outgoing_in_progress = mysqli_query($db_dehari, $query_outgoing_in_progress);
        $result_outgoing_in_progress_array = array();
        if ($result_outgoing_in_progress) {
            while ($result_outgoing_in_progress_row = mysqli_fetch_assoc($result_outgoing_in_progress))
                    $result_outgoing_in_progress_array[] = $result_outgoing_in_progress_row;
        }

        $result_outgoing_completed = mysqli_query($db_dehari, $query_outgoing_completed);
        $result_outgoing_completed_array = array();
        if ($result_outgoing_completed) {
            while ($result_outgoing_completed_row = mysqli_fetch_assoc($result_outgoing_completed))
                    $result_outgoing_completed_array[] = $result_outgoing_completed_row;
        }

        // close connection
        mysqli_close($db_dehari);

?>


    <!-- Page Content -->
    <div class="container">
        <div class="row" id="user_overview">
            <div class="col-md-3">
                <h4>
                    incoming rating:
                    </br>
                    earnings:
                </h4> 
            </div>
            <div class="col-md-3">
                <h4>
                    <? for ($i = 1; $i <= $user_incoming_rating; $i++) { ?>
                            <span class="glyphicon glyphicon-star dehari_red" aria-hidden="true"></span>
                    <? } ?>
                    
                    </br>
                    PKR <?=$user_incoming?>
                </h4> 
            </div>
            <div class="col-md-3">
                <h4>
                    outgoing rating:
                    </br>
                    expenditures:
                </h4>
            </div>
            <div class="col-md-3">
                <h4>
                    <? for ($i = 1; $i <= $user_outgoing_rating; $i++) { ?>
                            <span class="glyphicon glyphicon-star dehari_brown" aria-hidden="true"></span>
                    <? } ?>
                    
                    </br>
                    PKR <?=$user_outgoing?>
                </h4>
            </div>
        </div>

        <hr>

        <div class="row" id="incoming_outgoing">


            <div class="col-md-6" id="incoming_table_section">

                
                <div class="row" id="incoming_dehari_filters">
                    <div class="col-md-4">
                        Title:<input id="incoming_dehari_title" type="text"/>
                    </div>
                    <div class="col-md-4">  
                        Status:</br>
                        <select id="incoming_dehari_status">
                          <option selected value=""></option>
                          <option value="Bids Submitted">Bids Submitted</option>
                          <option value="Work In Progress">Work In Progress</option>
                          <option value="Work Completed">Work Completed</option>
                        </select>
                    </div>
                     <div class="col-md-4">  
                        <a href="#clear" id="clear_incoming_search_button" title="clear filter">[clear]</a>
                        </br>
                        <input id="incoming_search_button" type="button" value="SEARCH">
                    </div>
                </div>



                <table class="table incoming_dehari_table display" >
                    <thead>
                        <tr>
                            <th data-sort-initial="true">
                                Title
                            </th>
                            <th data-sort="true">
                                Category
                            </th>
                            <th data-hide="phone,tablet">
                                City
                            </th>
                            <th data-hide="phone,tablet">
                                Date Posted
                            </th>
                            <th data-hide="phone">
                                Status
                            </th>
                        </tr>
                    </thead>
                    <tbody>
<? foreach ($result_incoming_bids_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="incoming_bids_submitted_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Bids Submitted</td>
                        </tr>
<? } ?>

<? foreach ($result_incoming_in_progress_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="incoming_in_progress_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Work In Progress</td>
                        </tr>
<? } ?>

<? foreach ($result_incoming_completed_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="incoming_completed_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Work Completed</td>
                        </tr>
<? } ?>
                    </tbody>
                </table>
                    

                </h2> 
            </div>
            
            <div class="col-md-6" id="outgoing_table_section">

                
                <div class="row" id="outgoing_dehari_filters">
                    <div class="col-md-4">
                        Title:<input id="outgoing_dehari_title" type="text"/>
                    </div>
                    <div class="col-md-4">  
                        Status:</br>
                        <select id="outgoing_dehari_status">
                          <option selected value=""></option>
                          <option value="Work Posted">Work Posted</option>
                          <option value="Bids Received">Bids Received</option>
                          <option value="Work In Progress">Work In Progress</option>
                          <option value="Work Completed">Work Completed</option>
                        </select>
                    </div>
                     <div class="col-md-4">  
                        <a href="#clear" id="clear_outgoing_search_button" title="clear filter">[clear]</a>
                        </br>
                        <input id="outgoing_search_button" type="button" value="SEARCH">
                    </div>
                </div>



                <table class="table outgoing_dehari_table display" >
                    <thead>
                        <tr>
                            <th data-sort-initial="true">
                                Title
                            </th>
                            <th data-sort="true">
                                Category
                            </th>
                            <th data-hide="phone,tablet">
                                City
                            </th>
                            <th data-hide="phone,tablet">
                                Date Posted
                            </th>
                            <th data-hide="phone">
                                Status
                            </th>
                        </tr>
                    </thead>
                    <tbody>

<? foreach ($result_outgoing_posted_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="outgoing_posted_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Work Posted</td>
                        </tr>
<? } ?>

<? foreach ($result_outgoing_bids_received_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="outgoing_bids_received_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Bids Received</td>
                        </tr>
<? } ?>

<? foreach ($result_outgoing_in_progress_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="outgoing_in_progress_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Work In Progress</td>
                        </tr>
<? } ?>

<? foreach ($result_outgoing_completed_array as $dehari_row) { ?>
                        <tr>
                            <td><a href="#" class="outgoing_completed_details" id="dehari_list_id_<?=$dehari_row['dehari_id']?>"><?=$dehari_row['dehari_title']?></a></td>
                            <td><?=$dehari_row['dehari_category']?></td>
                            <td><?=$dehari_row['dehari_city']?></td>
                            <td data-value="78025368997"><?=(new DateTime($dehari_row['dehari_date']))->format('m/d/Y')?></td>
                            <td data-value="1">Work Completed</td>
                        </tr>
<? } ?>
                    </tbody>
                </table>
                    

                </h2> 
            </div>


        </div>

    </div>
    <!-- /.container -->

<!-- INCOMING -->
    <!-- Bids Submitted -->
        <div id="incoming_bids_submitted_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_bids_submitted_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="incoming_bids_submitted_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
                Bid:<input type="number" min="1" id="incoming_bids_submitted_dehari_bid_popup" placeholder="Enter Bid">
            </div>
            <div class="col-md-6">
                Message Client:<input type="textarea" id="incoming_bids_submitted_dehari_message_popup" value="">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="incoming_bids_submitted_update_dehari_button" type="button" value="UPDATE">
            </div>
            <div class="col-md-2">
                 </br>
                 <input id="incoming_bids_submitted_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Bids Submitted -->

    <!-- Incoming - Work In Progress -->
        <div id="incoming_in_progress_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_in_progress_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="incoming_in_progress_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
                Bid:<input type="number" min="1" id="incoming_in_progress_dehari_bid_popup" placeholder="Enter Bid" disabled>
            </div>
            <div class="col-md-8">
                Message Client:<input type="textarea" id="incoming_in_progress_dehari_message_popup" value="">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="incoming_in_progress_send_button" type="button" value="SEND">
            </div>

        </br>
            <div class="col-md-12">
                <hr>
            </div>
               
            <div class="col-md-6">
            </div>
            <div class="col-md-2">
                Rate Client:
                <input type="number" min="0" max="5" step="0.5" id="incoming_in_progress_rate_popup" value="5">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="incoming_in_progress_mark_complete_button" type="button" value="MARK COMPLETE">
            </div>
            <div class="col-md-2">
                 </br>
                 <input id="incoming_in_progress_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Work In Progress -->

    <!-- Incoming - Work Completed -->
        <div id="incoming_completed_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="incoming_completed_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_completed_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_completed_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="incoming_completed_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_completed_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="incoming_completed_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="incoming_completed_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
                Price:<input type="number" min="1" id="incoming_completed_dehari_bid_popup" placeholder="Enter Bid" disabled>
            </div>
            <div class="col-md-2">
            </div>
            <div class="col-md-2">
                Rating Received:<input type="number" min="0" max="5" step="0.5" id="incoming_completed_in_rate_popup" placeholder="Rate" disabled>
            </div>
            <div class="col-md-2">
                Rating Given:<input type="number" min="0" max="5" step="0.5" id="incoming_completed_out_rate_popup" placeholder="Rate" disabled>
            </div>
            <div class="col-md-2">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="incoming_completed_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Work Completed -->

<!-- OUTGOING -->
    <!-- Work Posted -->
        <div id="outgoing_posted_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="outgoing_posted_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_posted_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_posted_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_posted_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_posted_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_posted_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="outgoing_posted_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
            </div>

            <div class="col-md-6">
            </div>

            <div class="col-md-2">
            </div>

            <div class="col-md-2">
                 <input id="outgoing_posted_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Work Posted -->


    <!-- Bids Received -->
        <div id="outgoing_bids_received_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-12">
                <table class="table outgoing_bids_received_table display" >
                    <thead>
                        <tr>
                            <th data-sort-initial="true">
                                Dehari ID
                            </th>
                            <th data-sort-initial="true">
                                User ID
                            </th>
                            <th data-sort-initial="true">
                                Amount
                            </th>
                            <th data-sort="true">
                                Message
                            </th>
                            <th data-hide="phone,tablet">
                                User Name
                            </th>
                            <th data-hide="phone,tablet">
                                User Rating
                            </th>
                            <th data-hide="phone">
                                Action
                            </th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
                
            </div>

        </br>
            <div class="col-md-2">
            </div>

            <div class="col-md-6">
            </div>

            <div class="col-md-2">
            </div>

            <div class="col-md-2">
                 <input id="outgoing_bids_received_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Bids Received -->

    <!-- Outgoing - Work In Progress -->
        <div id="outgoing_in_progress_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_in_progress_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="outgoing_in_progress_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
                Bid:<input type="number" min="1" id="outgoing_in_progress_dehari_bid_popup" placeholder="Enter Bid" disabled>
            </div>
            <div class="col-md-8">
                Message Worker:<input type="textarea" id="outgoing_in_progress_dehari_message_popup" value="">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="outgoing_in_progress_send_button" type="button" value="SEND">
            </div>

        </br>
            <div class="col-md-12">
                <hr>
            </div>
               
            <div class="col-md-6">
            </div>
            <div class="col-md-2">
                Rate Worker:
                <input type="number" min="0" max="5" step="0.5" id="outgoing_in_progress_rate_popup" value="5">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="outgoing_in_progress_mark_complete_button" type="button" value="MARK COMPLETE">
            </div>
            <div class="col-md-2">
                </br>
                 <input id="outgoing_in_progress_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
        </div>
    <!-- END Work In Progress -->

    <!-- Outgoing - Work Completed -->
        <div id="outgoing_completed_popup" title="Dehari" style="display:none">
        <div class="row">
            <div class="col-md-2">
                <div id="outgoing_completed_dehari_title_popup">
                Title
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_completed_dehari_address_popup">
                Address
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_completed_dehari_city_popup">
                City
                </br>
                </div>
            </div>


            <div class="col-md-2">
                <div id="outgoing_completed_dehari_category_popup">
                Category
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_completed_dehari_phone_popup">
                Phone
                </br>
                </div>
            </div>

            <div class="col-md-2">
                <div id="outgoing_completed_dehari_budget_popup">
                Budget
                </br>
                </div>
            </div>


        </br>
            <div class="col-md-12">
                <div id="outgoing_completed_dehari_description_popup">
                Description
                </br>
                </div>
            </div>

        </br>
            <div class="col-md-2">
                Price:<input type="number" min="1" id="outgoing_completed_dehari_bid_popup" placeholder="Enter Bid" disabled>
            </div>
            <div class="col-md-2">
            </div>
            <div class="col-md-2">
                Rating Received:<input type="number" min="0" max="5" step="0.5" id="outgoing_completed_in_rate_popup" placeholder="Rate" disabled>
            </div>

            <div class="col-md-2">
                Rating Given:<input type="number" min="0" max="5" step="0.5" id="outgoing_completed_out_rate_popup" placeholder="Rate" disabled>
            </div>
            <div class="col-md-2">
            </div>
            <div class="col-md-2">
                 </br><input id="outgoing_completed_close_dehari_button" type="button" value="CLOSE">
            </div>

        </div>
    </div>
    <!-- END Work Completed -->


    <footer> 
      <div id="navbar" class="collapse navbar-collapse text-center">

          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Help</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#about">Terms</a></li>
            <li><a href="#contact">Privacy</a></li>
            <li><a href="#">Cookies</a></li>
            <li><a href="#about">Advertise</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
          
        </div>                                          
    </footer>

    <!-- jQuery -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>

    <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="https://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
    

    <script src="js/home_dehari.js" type="text/javascript"></script>
    <script src="js/jquery.dataTables.min.js" type="text/javascript"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>