$( document ).ready( function() {

  $("#signup_button").click(function () {
  var user_name = $('#dehari_sign_user_name').val();
  var pass_word = $('#dehari_sign_pass_word').val();

  $.ajax
      ({
          type: "POST",
          //the url where you want to sent the userName and password to
          url: "server/authenticate.php",
          //json object to sent to the authentication url
          data : {
          signup: 1,
          username : user_name,
          password: pass_word
        } }).done(function(raw_data) {
          var data = JSON.parse(raw_data);
          $("#dehari_index_popup").html( "<p> " + data + "</p>" );
          if (data === "Username created successfully!") {
              $("#dehari_index_popup").append( "<p>Email: <input type=\"text\" id=\"dehari_enter_info_email\"></p><input id=\"dehari_enter_info_button\" type=\"button\" value=\"ENTER\">" );
              $("#dehari_index_popup" ).dialog({
                  dialogClass: 'popup_style',
                  title: 'Success!',
                  modal:true
                });
          } else {
              $("#dehari_index_popup").dialog({
                  dialogClass: 'popup_style',
                  title: 'Failed',
                  modal:true
                });
          }

      });

  });

  $("#login_button").click(function () {
    var user_name = $('#dehari_user_name').val();
    var pass_word = $('#dehari_pass_word').val();


    $.ajax
        ({
            type: "POST",
            //the url where you want to sent the userName and password to
            url: "server/authenticate.php",
            //json object to sent to the authentication url
            data : {
            login: 1,
            username : user_name,
            password: pass_word
          } }).done(function(raw_data) {
            if (raw_data === "-1") {
                $("#dehari_index_popup").html( "<p>Username or password is incorrect. <br /> Try again.</p>" );
                $("#dehari_index_popup" ).dialog({
                  dialogClass: 'popup_style',
                  title: 'Login Failed',
                  modal:true
                });
            } else {
              var user_string = JSON.parse(raw_data);
              var user_id = parseInt(user_string);
              window.location.href = "home_dehari.php";
            }
        });

    });

    $("#dehari_index_popup").on('click', '#dehari_enter_info_button', function() {
      var userEmail = $('#dehari_enter_info_email').val();

      $.ajax
          ({
              type: "POST",
              //the url where you want to sent the userName and password to
              url: "server/authenticate.php",
              //json object to sent to the authentication url
              data : {
              enterinfo: 1,
              user_email : userEmail
            } }).done(function(raw_data) {
              
              if ($.trim(raw_data) === "success") {

                window.location.href = "home_dehari.php";
              } else {
                  $("#dehari_index_popup").append( "<p> Failed! </p>" );
              }

          });

      });






});
